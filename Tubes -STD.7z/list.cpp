#include "head.h"

void createmList(mList &L) {
    mfirst(L) = NULL;
}

void createkList(kList &L) {
    kfirst(L) = NULL;
}

bool ismEmpty (mList L) {
    if (mfirst(L) == NULL)
        return true;
    else
        return false;
}

bool iskEmpty (kList L) {
    if (kfirst(L) == NULL)
        return true;
    else
        return false;
}

r_adr r_Allocation(infotype X) {
    r_adr P = new elm_rls;
    s_rnext(P) = NULL;
    d_rnext(P) = NULL;
    return P;
}

m_adr m_Allocation(infotype X) {
    m_adr P = new elm_mbl;
    m_info(P) = X;
    d_mnext(P) = NULL;
    s_mnext(P) = NULL;
    return P;
}

k_adr k_Allocation(infotype X) {
    k_adr P = new elm_kry;
    k_info(P) = X;
    d_knext(P) = NULL;
    return P;
}

void m_insert (mList &L, m_adr P) {
    if (ismEmpty(L)) {
        mfirst(L) = P;
    } else {
        m_adr Q = mfirst(L);
        while (d_mnext(Q) != NULL) {
            Q = d_mnext(Q);
        } d_mnext(Q) = P;
    }
}

void k_insert (kList &L, k_adr P) {
    if (iskEmpty(L)) {
        kfirst(L) = P;
    } else {
        k_adr Q;
        Q = kfirst(L);
        while (d_knext(Q) != NULL) {
            Q = d_knext(Q);
        } d_knext(Q) = P;
    }
}

m_adr mSearch (infotype mobil, mList L) {
    m_adr P = mfirst(L);
    while ((m_info(P) != mobil) && (d_mnext(P) != NULL)) {
        P = d_mnext(P);
    } if (m_info(P) == mobil) {
        return P;
    } else {
        return NULL;
    }
}

k_adr kSearch (infotype montir, kList L) {
    k_adr P = kfirst(L);
    while ((k_info(P) != montir) && (d_knext(P) != NULL)) {
        P = d_knext(P);
    } if (k_info(P) == montir) {
        return P;
    } else {
        return NULL;
    }
}

void createRel (mList L, kList K,infotype mobil, infotype montir) {
    if (kSearch(montir, K) == NULL) {
        cout<<"Tidak ada montir dengan nama tsb \n";
        if (mSearch(mobil, L) == NULL) {
            cout<<"Tidak ada mobil dengan merk tersebut \n";
        }
    } else {
        r_adr S = new elm_rls;
        r_adr Q = s_mnext(mSearch(mobil, L));
        if (Q != NULL) {
            while (s_rnext(Q) != NULL) {
                Q = s_rnext(Q);
            }
            s_rnext(Q) = S;
        } else {
            s_mnext(mSearch(mobil,L)) = S;
        }
        d_rnext(S) = (kSearch(montir, K));
        s_rnext(S) = NULL;
    }
}

void printInfo(mList L, kList K) {
    m_adr P = mfirst(L);
    r_adr J;
    int i = 1;
    while (P != NULL) {
        cout<<i<<".\tMobil  : "<<m_info(P)<<endl;
        i++;
        J = s_mnext(P);
        while (J != NULL) {
            cout<<"\tMontir : "<<k_info(d_rnext(J))<<endl;
            J = s_rnext(J);
        } cout<<"=========================="<<endl;
        P = d_mnext(P);
    }
}

void del_Mobil (mList &L, infotype &Q) {
//    m_adr P = mfirst(L);
//    m_adr Prec = mSearch(m_info(Q), L);
//    if (ismEmpty(L)) {
//        cout<<"List masih belum terisi \n";
//    } else {
//        if (Prec != NULL) {
//            if (P == Prec ) {
//                mfirst(L) = d_mnext(P);
//                d_mnext(P) = NULL;
//            } else {
//                if (d_mnext(Prec) == NULL) {
//                    while (d_mnext(P) != Prec) {
//                        P = d_mnext(P);
//                    } d_mnext(P) = NULL;
//                    P = Prec;
//                } else {
//                    while (d_mnext(P) != Prec) {
//                        P = d_mnext(P);
//                    } d_mnext(P) = d_mnext(Prec);
//                    d_mnext(Prec) = NULL;
//                    P = Prec;
//                }
//            } Q = P;
//        } else {
//            cout<<"Tidak ada mobil dengan merk tsb \n";
//        }
//    }
}

void del_Montir (kList &L, infotype montir, k_adr &Q) {
    k_adr P = kfirst(L);
    k_adr Prec = kSearch (montir, L);
    if (iskEmpty(L)) {
        cout<<"List masih belum terisi \n";
    } else {
        if (Prec != NULL) {
            if (P == Prec ) {
                kfirst(L) = d_knext(P);
                d_knext(P) = NULL;
            } else {
                if (d_knext(Prec) == NULL) {
                    while (d_knext(P) != Prec) {
                        P = d_knext(P);
                    } d_knext(P) = NULL;
                    P = Prec;
                } else {
                    while (d_knext(P) != Prec) {
                        P = d_knext(P);
                    } d_knext(P) = d_knext(Prec);
                    d_knext(Prec) = NULL;
                    P = Prec;
                }
            } Q = P;
        } else {
            cout<<"Tidak ada montir dengan nama tsb \n";
        }
    }
}



