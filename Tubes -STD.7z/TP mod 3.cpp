#include "head.h"

using namespace std;

int main() {
    infotype mobil,montir;
    mList Lcar;
    kList Lmech;
    createkList(Lmech);
    createmList(Lcar);
    m_insert(Lcar, m_Allocation("Avanza"));
    m_insert(Lcar, m_Allocation("Jazz"));
    m_insert(Lcar, m_Allocation("Innova"));
    m_insert(Lcar, m_Allocation("Mobilio"));
    k_insert(Lmech, k_Allocation("Ayyub"));
    k_insert(Lmech, k_Allocation("Ferry"));
    k_insert(Lmech, k_Allocation("Heri"));
    k_insert(Lmech, k_Allocation("Tirto"));
    k_insert(Lmech, k_Allocation("Mat"));
    k_insert(Lmech, k_Allocation("Kan"));
    createRel (Lcar, Lmech, "Avanza", "Ferry");
    createRel (Lcar, Lmech, "Jazz", "Ayyub");
    createRel (Lcar, Lmech, "Innova", "Heri");
    createRel (Lcar, Lmech, "Mobilio", "Tirto");
    createRel (Lcar, Lmech, "Avanza", "Mat");
    createRel (Lcar, Lmech, "Avanza", "Kan");
    createRel (Lcar, Lmech, "Jazz", "Kan");
    printInfo(Lcar,Lmech);
    del_Mobil (Lcar, "Jazz");
    printInfo(Lcar,Lmech);
return 0;
}
